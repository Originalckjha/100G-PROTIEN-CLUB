import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import express from 'express';
import cors from 'cors';
import usersRouter from './routes/users';
import recipesRouter from './routes/recipes';
import tipsRouter from './routes/tips';
import postsRouter from './routes/posts';

const app = express();
const PORT = process.env.PORT ?? 3001;

app.use(cors({ origin: ['http://localhost:5173', 'http://127.0.0.1:5173'] }));
app.use(express.json());

app.get('/api/health', (_req, res) => res.json({ status: 'ok', app: '100G Protein Club API' }));

app.use('/api/users', usersRouter);
app.use('/api/recipes', recipesRouter);
app.use('/api/tips', tipsRouter);
app.use('/api/posts', postsRouter);

// Unknown API routes get a JSON 404, never the HTML page
app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found' }));

// In production, this same server also serves the built React app,
// so the site and the API share one URL and '/api' just works.
const clientDist = path.resolve(__dirname, '../../frontend/dist');
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  // Let React Router handle deep links like /recipes/recipe-1 on refresh
  app.get('*', (_req, res) => res.sendFile(path.join(clientDist, 'index.html')));
}

app.listen(PORT, () => {
  console.log(`🥩 100G Protein Club running on port ${PORT}`);
});

export default app;
